# Shivam Dixit Digital Resume

A digital resume website built based on the content from my personal REAL [resume](./assets/resume.pdf) 

View live demo here using github pages: [Live Demo](https://shivvu.github.io/Digital-Portfolio/))

## Dark Mode Preview

<img src="assets\images\dark mode preview.jpg">


```
